export class Employee {
 
 
      id:any
      firstName:any
      lastName:any
      email:any
    
  
  constructor(id:any,firstName:any,lastName:any,email:any){
      this.id= id;
      this.firstName=firstName;
      
      this.lastName=lastName;
      this.email=email;
  }
  
  }
  
  
  




  
  


