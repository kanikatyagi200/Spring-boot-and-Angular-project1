import { ThisReceiver } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {

  employee: Employee;
  employees: Employee[] = [];
  
  employeeService: EmployeeService;
  router:Router;
  constructor( employeeService: EmployeeService, router:Router) { 
    this.employee=new Employee('','','','');
    this.employeeService=employeeService;
    this. router=router;
  }

  ngOnInit(): void {
    this.employeeService.getEmployeeList().subscribe((data: Employee[])=>{

      console.log(data);

      this.employees= data; 

    })  
  }
  


  
  




saveEmployee(){

 this.employeeService.createEmployee(this.employee)

 

}


goToEmployeeList(){

this.router.navigate(['/employees'])
  
}

onSubmit(){

  console.log(this.employee);
  this.saveEmployee();
}

}
