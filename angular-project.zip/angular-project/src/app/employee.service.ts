
import { Injectable } from '@angular/core';
import { Observable, retry } from 'rxjs';
import { Employee } from './employee';
import { HttpHeaders, HttpClient, HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {


  baseURL: string;
  httpOptions = {

    headers: new HttpHeaders({

      'Content-Type': 'application/json'

    })

  }
  constructor(private httpClient: HttpClient) {
    this.baseURL = "http://localhost:8080";
  }
  getEmployeeList(){

    return this.httpClient.get<Employee[]>(this.baseURL + '/employees', this.httpOptions)

      

   }

  
  createEmployee(employee: Employee): void {

     this.httpClient.post<Employee>(this.baseURL + '/addemployees', JSON.stringify(employee), this.httpOptions)
    .subscribe((response: any) => {console.log("This is book response: " + response);

      }



    );}

updatedEmployee(id: number, employee: Employee) {

    return this.httpClient.put(this.baseURL + '/putemployees/'+id, employee);

  }

  deleteEmployee(id: number) {

     return this.httpClient.delete(this.baseURL + '/delemployees/'+id,this.httpOptions);

  }
  findemp(id:number){
    return this.httpClient.get<Employee>(this.baseURL + '/findemp/'+id,this.httpOptions);
  }
  
}
