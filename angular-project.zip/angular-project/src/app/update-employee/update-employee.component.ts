import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {
  employee: Employee;
  employees: Employee[] = [];
  id:number
  
  employeeService: EmployeeService;
  router:Router;
  constructor( employeeService: EmployeeService, router:Router,private router1:ActivatedRoute) { 
    this.employee=new Employee('','','','');
    this.employeeService=employeeService;
    this. router=router;
  }

  ngOnInit(): void {
    
    
this.router1
 .queryParams
.subscribe(params => {
 console.log(params);
 this.id= params['id'];
 console.log(this.id);
}

 );

    this.employeeService.findemp(this.id).subscribe((data:Employee)=>{
      this.employee=data
    });
    this.employeeService.getEmployeeList().subscribe((data: Employee[])=>{

      console.log(data);

      this.employees= data;

    })  
  }

  saveEmployee(){

 this.employeeService.createEmployee(this.employee)

}

goToEmployeeList(){

this.router.navigate(['/employees'])
  
}

onSubmit(){

  console.log(this.employee);
  this.saveEmployee();
}

}
  
