import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  employee: Employee;
  employeedao:EmployeeService;
  constructor(employeedao:EmployeeService) {
    this.employeedao=employeedao;
    this.employee= new Employee('','','','');
   }

  ngOnInit(): void {
  }
  onSubmit(from:any){

    console.log(this.employee.id);
    this.employeedao.findemp(from.value.id).subscribe((data: Employee)=>{

      console.log(data);

     

    })  ;
  }

}
