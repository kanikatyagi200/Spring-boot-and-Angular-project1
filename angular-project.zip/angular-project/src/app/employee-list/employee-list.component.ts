import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { observable,Subject} from "rxjs";
@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

 

  employees:Employee[];

  constructor(private employeeService: EmployeeService,private router:Router) {
    this.employees=[];
  }

  ngOnInit(): void {
    this.employeeService.getEmployeeList().subscribe((data: Employee[])=>{

      console.log(data);

      this.employees= data;

    })  
  }
  

    

  

   
     //this.getEmployees();

    
  //   this.employees=[{

  //   "id":1,
  //   "firstName":"Kanika",
  //   "lastName":"Tyagi",
  //   "email":"kt@gmail.com"

  //  },
   
  


  //  {

  //   "id":2,
  //   "firstName":"Jaya",
  //   "lastName":"Sharma",
  //   "email":"jy@gmail.com"

  //   }
   
  //  ]

  


  private getEmployees(){

   this.employeeService.getEmployeeList().subscribe(data =>{
    
    console.log(data);
    this.employees=data;
   });

  }
  

 updateEmployee(id1: number){
   
  
  this.router.navigate(['/update-employee'],{queryParams:{id:id1}});


 }


deleteEmployee(id:number){

this.employeeService.deleteEmployee(id).subscribe(()=>{
console.log("employee with id"+id+"was deleted");

 

});
this.getEmployees();

}


}

